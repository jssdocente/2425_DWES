classDiagram
direction BT
class album_user {
   datetime created_at
   datetime updated_at
   varchar album_id
   integer user_id
}
class albums {
   varchar code
   varchar name
   varchar type
   varchar albumType
   integer totalTracks
   varchar imagedUrl
   date releaseDate
   varchar artist_id
   datetime created_at
   datetime updated_at
   varchar id
}
class artists {
   varchar code
   varchar name
   varchar type
   varchar genre
   varchar imagedUrl
   date releaseDate
   integer popularity
   datetime created_at
   datetime updated_at
   varchar id
}
class followers {
   integer user_id
   varchar album_id
}
class playlist_track {
   datetime created_at
   datetime updated_at
   varchar playlist_id
   varchar track_id
}
class playlists {
   varchar name
   varchar description
   integer totalTracks
   varchar imagedUrl
   datetime created_at
   datetime updated_at
   integer App\Models\User
   varchar id
}
class tracks {
   varchar code
   varchar name
   varchar type
   integer duration
   integer trackNumber
   integer popularity
   varchar album_id
   datetime created_at
   datetime updated_at
   integer playedTimes
   varchar id
}
class users {
   varchar name
   varchar email
   datetime email_verified_at
   varchar password
   varchar remember_token
   datetime created_at
   datetime updated_at
   integer id
}

album_user  -->  albums : album_id:id
album_user  -->  users : user_id:id
albums  -->  artists : artist_id:id
followers  -->  albums : album_id:id
followers  -->  users : user_id:id
playlist_track  -->  playlists : playlist_id:id
playlist_track  -->  tracks : track_id:id
tracks  -->  albums : album_id:id
