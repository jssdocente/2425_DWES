<?php

namespace Database\Seeders;

use App\Models\Album;
use App\Models\Track;
use Illuminate\Database\Seeder;

class AlbumSeeder extends Seeder {
  public function run(): void {

    //Crear 20 albumes
//    for ($i = 0; $i < 20 ; $i++) {
//      try {
//        $album = Album::factory()->create();
//        try {
//          Track::factory(rand(10, 15))->create(['album_id' => $album->id]);
//        } catch (\Exception ) {}
//      } catch (\Exception) {}
//    }

  }
}
