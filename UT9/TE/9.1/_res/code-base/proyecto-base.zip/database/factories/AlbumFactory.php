<?php

namespace Database\Factories;

use App\domain\spotify\AlbumSpotify;
use App\Models\Album;
use App\Models\Artist;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;

class AlbumFactory extends Factory {
  protected $model = Album::class;

  public function definition(): array {
    $id = $this->faker->asciify('****************');

    $abumnsId = [
      "0p0FGxiCrl3afABenvtWbQ","2knEuvsxqHMAoxlQpIdpQD","4T1zaLt2uHXf8qAscsSP60","5NvTqZLsXER3w6x3KYdABH","0Ye07YKpMKTynGPopYcVNQ","5UHzX6Fplo96Xd5tUyT0hP","5mojJwWgWNJcY3odUGgQc3","4HTjKPVHHS4acq6evIpQj6","4qNag8cUD12cazCepgfZ6O","5O0zUvdnJr0RbWzLFneN2i","0mCLQVHEZ3X8k4sE0yyNZq","5IVJbSDDWbGjKbBczyifFl","32Nl49izVyngH22kD1lrkk","6zJcDGIgURV28s5IdA9pSG","261Ss3QURXkZ55P6CZWfyS","5scxi8dzsvkrH6TamZv6NP","5HtZb8vYuUU788VPRCXUxH","7e7t0MCrNDcJZsPwUKjmOc","78qD6T34x0zDcg3PFyh4zl","2gFPCLIFTBgpeg0NuoOOMq","47GIqQLij95giKHHkZdWNT","1C73GINRGuFTt2swTJQ6Y2","0UnBZ8laFgLUq5Ty5vbikQ","5ubxg7F0sp7DxUVGK2fi6V","2qJqTqEUp5TD9CNie4XMtg","5lOqHvmo0y3yfvFvxm9Ygs","3mlVZ7OTZgKJJAr275tHZX","48gEWN2OrlF8v02rYcDYoU","2gabUrIWEhT9eeVjM749jX","5Qk1y41EXPWr98u1TsH35Y","3hnuMKQGxPhmpz65TWYvJl","1RHa1VdX6lsLbeedgsV1cb","4GVwsl8qQPoU8lqEjrvZVO","6dkIaqXD9J0PUPZrgfPAUq","06DLdjStAj7Gn1eEJfMuLP","2HIwUmdxEl7SeWa1ndH5wC","71YgRizHk35FJrOjTwgGtf","3hWEzJN9LQP83KNW13AXIe","5nNtpPsSUgb9Hlb3dF1gXa","1ZMNqhcar5rjEgjWZ6WFv1","7fYpPxSSZpIX17Kv6RtZNG","0EZoxOrmBvdaYl7IY6LBW7","4dt3F1qHPHLtgchFjlAZLm","09OCpQKLhqJB8Ro2Us3Kpk","4gxFqhVYU4wp1XDH1KiIo4","2nGhGNH8tCKJofFxwhSGTE","4w3MSrsY0ttLMH3F4X1Jks","5VFE7ZIABJj5cIsx5AueHy","1WkGbKUjhOMru7uYl25jJb","5wMt0kebk8uzBoESJ4MRRJ",
      "2K72Xpc2mhuNAIz2mwcvwt", "6T2asuu0fs4I1dnH0YLII3", "249z3MS2m8SeEeDuoDVjWB", "5KL8P1fwRCI0CM6zRGbR9Y", "0NsjS0pQjZScnULzoKNsty", "223iwdcpZPEO9xnXJtrZMo", "6oM5BegPi6sMgy6V609GQv", "42DSffEFcnolfC58jXRWIb", "4MZnolldq7ciKKlbVDzLm5", "5t2liWeXpF0ourQ34qfQiC", "6d1vGZsr6Uy3h9IigBpPAf", "0szC3aA7V8qdBFRbHZwlX6", "0Jh7XIEQrNQAXm7a6hbJ1h", "1ZstjA64azkUw5kpFfg1BL", "76pWhtPUKI4MVWpc05Ykhh", "0b3m9EiH4QT9wuqCEKvS9q", "18Cf3fPeZ5mRYI8ihYBhqo", "58y2kTOU9Wfb6zGDzBXAo0", "1zboj6eF8tdabKIeF5Y84a", "571VRE5q9JXEdzzBOvyACB", "1VKTFfVYpTNLzyMNJCJanb", "1l7q5CXuXdKs2rmYMEBSiS", "494knQzuPcvzGZbn6zoImo", "0lZs62Ufvinlm6rBdnD6TR", "3q0jSQN78hoqBtXB2JDaw5", "5W7sRG021T8HyqGzivQrkg", "0DuM9D6Kz3YQgyogYRHS39", "36cY4fG1CXpHkBNGLqyzhp", "2MDU46hcBn3u94s46BOSdv", "3Krqq6QfFgzp2ifGI73OrR", "1H2rcmLVAoMyiuh9ponsYA", "01NJZ9IvH2w0291m9atK96", "2OTeVRjNthWI2dtzEPnlyF", "1VrLTUE5ivuWa49Cd63MSx", "1ZDQYGZ7ETRcIWgHQRNQp1", "50SeADsy7z2OlZiluYb6wp", "0ApyLPuanH7TrIazuIVfVg", "70iQpz4rX77h7PbXSpaQra", "2ZdF0MMUCaIN52rySZXIQZ", "6W57cYC1b5f1Lc1oZSTtT7", "4jrWunUBkUjnBRtMfXYf6k", "69teKmxjxydgLFFpCEUWK2", "2dS7ZvI11mL5IQjsckGSCp", "4qfQWPGyGPSyMR54KeIXu7", "6DuO60J8HnOe7ZSGL35jGf", "6umlnTChFEpySNhnvcLWKE", "5ZPyZ4uSurGAfwOingItMR", "1MJxcAG1eaChFMRXOY4SW9", "7D7qUgx5iAYJ0TaGsuQqTv", "0Bw5c50SOPxXHvL6GfM9Tc",
      "1jdNwZ40MrCXBVUNMwrxXB", "69FfsvVstJkFev5cAgRhFs", "6dODtvKEopRhK5dKC7OZD6", "2mGQLhWyjwx3nYYPQtgkdw", "3aFzA2HdHDWyWmg9eh87IN", "4oXJy1AZb6TYWv8po6oRpU", "0HpGyFlPIScbtN6TV1Zo44", "4vVaGBF0V6Gwz1Ni243DE5", "3KxlIjWVbspM43s8jjKLn8", "1Jm2EPHcfmxfX1EleRoOkK", "3v3s1YhnnWUkQnZMotDz5U", "2qih9xiijaVf7ZBYJwgDMA", "2juE7Iqae6CYBdudNni8Qu", "3MJfMtxaK8aHRFQk1Aqzcl", "51XcevuRxHf3HOugcewEZv", "3hXEP8hHHyLwjYz49dR1Ce", "3gAgJgN6KdKlbTAdVkFzgs", "0R3hkVwqUQAqL75EKq7b1I", "5GKXAJLh8zlgNZA3qybaMt", "7FfvCgqDR7xDRVD509V1WS", "1OMWShFoeWWvDwZiGu9yQk", "5HqzVjfKEE9nMOYpQxQiz1", "4O1DmLhOLlDPMG2m9mo6rL", "0IZmMihiL2P3wlOyAGqaAZ", "3qpAHoOLWeXRNTaGzeYf13", "6jARCNFtj4Nn4rfjoyuyPN", "2eFWG2ZnDaiiesSNssfaVc", "2lCyxNams86Tjw24BU7t5A", "4Onvp105vpwN2zgwEErDVH", "5OeAiEg5TsF2tKhwewL951", "2MlT9dGKoGH2hsfcz7UUXL", "7a3t9jgdtVKq8pVe7IpQVP", "2kLk6nNB65O9AA6EmaI5DG", "6hzZJZiQm0CRqNnqR9irdv", "7xUH9zHArUCcdFRvA585lJ", "2UWTR4LoZ1NU4AiZYs9MQR", "1bSsOP5q2aXB0TO2h6rKXg", "0YIOpXQvcbiDNPusSqi5Ew", "6bkmqDdKtkbn7pr7xihMv5", "4ksJGDgtixAqJ390XWv0Ua", "559V3ZrVMqvhdPz014VgGn", "1FdDdMeIdodt7JoJ9j7f0q", "33QIdvBtMb6tH4XmRBjPLj", "2f9y83gMpFqudgnhbUpBhV", "4mNY5N4wWB15LgIiZx0tlo", "2kBFECL9a71fNRXbRW5xO3", "1QCMJsTQC8osFp4j35PyKM", "6mIV0sMabeQn6SE99oEQf5", "4SgR6aQmDkviqC0AyYfFEu", "3GAHv86Yo9P3KCPmxYP8IO"
    ];

    $data = AlbumSpotify::fromJson(\Spotify::album(Arr::random($abumnsId))->get());

    return [
      'id' => $data->id,
      'code' => $data->id,
      'name' => $data->name,
      'type' => $data->type,
      'albumType' => $data->albumType,
      'imagedUrl' => $data->getImage(),
      'totalTracks' => $data->totalTracks,
      'artist_id' => Artist::factory(),
      'releaseDate' => $data->releaseDate,
      'created_at' => Carbon::now(),
      'updated_at' => Carbon::now(),
    ];
  }
}
