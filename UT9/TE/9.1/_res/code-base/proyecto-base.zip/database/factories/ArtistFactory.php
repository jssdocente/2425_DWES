<?php

  namespace Database\Factories;

  use App\domain\spotify\AlbumSpotify;
  use App\domain\spotify\ArtistSpotify;
  use App\Models\Artist;
  use Illuminate\Database\Eloquent\Factories\Factory;
  use Illuminate\Support\Arr;
  use Illuminate\Support\Carbon;

  class ArtistFactory extends Factory {
    protected $model = Artist::class;

    public function definition(): array
    {
      $artistIds = [
        "1Xyo4u8uXC1ZmMpatF05PJ","6tbjWDEIzxoDsBA1FuhfPW","2CmaKO2zEGJ1NWpS1yfVGz","0LyfQWJT6nXafLPZqxe9Of","5kiLQWZbkBhq7ITwdy86qp","2z1MpPojFcvxYcEAx0lT6w","2imGXK0ByVk44eGEf3I3Sk","51Blml2LZPmy7TTiAg47vQ","2imGXK0ByVk44eGEf3I3Sk","0N1TIXCk9Q9JbEPXQDclEL","1Xyo4u8uXC1ZmMpatF05PJ","6tbjWDEIzxoDsBA1FuhfPW","0LyfQWJT6nXafLPZqxe9Of","2ycnb8Er79LoH2AsR5ldjh","0J8cNhY7V2NoRt9O6uCeUX","1Cs0zKBU1kc0i8ypK3B9ai","3ADyFy1orEwODaiHmRRMQp","3aO2Q4cXKGxsh87bX4Oavo","5YqXgMhzkUnyjYQGgoIvoq","1CdLG4i1rTEOsex2UE0jCH","1URVdcNYXigvk6Dj0fHYOM","0eDvMgVFoNV3TpwtrVCoTj","2YIxQoGvBukvoC1CbJ7opS","4UqOY535n8GYr2SyMzIgcy","0LyfQWJT6nXafLPZqxe9Of","5TUiEbaMctmeKGtP46ssBB","4gOc8TsQed9eqnqJct2c5v","2kRfqPViCqYdSGhYSM9R0Q","2AfmfGFbe0A0WsTYm0SDTx","1XlwE6XhQCFKpTmZWEDY96","0LyfQWJT6nXafLPZqxe9Of","5rtJbmsfYD9YRIU5uuIhh6","6yZNRoEV9xmiIGgO3lAttd","4TaSvnT5o4REFwhqfrmK27","3L2gl8O5cKVCbAnSWUFZxf","3PRXdiVu8lUkeCKw4ZUX4B","0LyfQWJT6nXafLPZqxe9Of","5aBEGOeWQCJfptic9xyaAb","1vVHevk2PD45epYnDi9CCc","4lXotCIJXcPIhhd1du8hgX","61NIC7vUqXVRl0FWh2ChiD","1a934Bo8PYrALBPndbkISF","0bjfZaBZpnWPp8hxszeMND","25uiPmTg16RbhZWAqwLBy5","55IzEzlyUcBFqGgyam2Seo","6sLxAjfAYXJTAArCFzQp1Q","0QHgL1lAIqAw0HtD7YldmP","3TVXtAsR1Inumwj472S9r4","0qgxiUt2HZ0GoYRYF01aH5","0LyfQWJT6nXafLPZqxe9Of","0L3wrFI3QcbXAvFL7IaPQX","4ET82ZtSfAK4utfjDauImD","3bSyv1vO8ye6PKyWcJeVbI","4EocOI6ihwLrX0mT95nBOT","3aO7bmIMLhfVvWem4O7jR2","2CmaKO2zEGJ1NWpS1yfVGz","1UgUBnYpGyrYfGIfkMp08O","79lATyc2ODajhNfsqcNnzw","6o4L5N0aiAhdtN3pqEwG0P","6otlDH5fS4xvrdWd4u1aC6","06ykDuRqWsglkPUTFZJVpZ","5l8VQNuIg0turYE1VtM9zV","1NU0ZObN8L7r6QfAn6Rk26",
        "5LHRHt1k9lMyONurDHEdrp","55Aa2cqylxrFIXC767Z865","2ev9Ox31lfCypT94W86bXp","6EZ52Z24cCBx51BYtRAl0D","4bWHA8fMNjzfGPQqnh5D6y","1m9WPOccw8sizsVYUhSVjZ","0LyfQWJT6nXafLPZqxe9Of","0LyfQWJT6nXafLPZqxe9Of","4QDcs3XrA8uHUZ7Xt9Ytep","0LyfQWJT6nXafLPZqxe9Of","0LyfQWJT6nXafLPZqxe9Of","0eDvMgVFoNV3TpwtrVCoTj","7EvvLZS0GP7XuNlWFFXpFR","0eDvMgVFoNV3TpwtrVCoTj","7EH72y7UrbIEARoAY618rz","0LyfQWJT6nXafLPZqxe9Of","5rDWHA1JYXY31soG6Os9cY","6n4NX7cBWbkXX0uCKjfMl0","1URVdcNYXigvk6Dj0fHYOM","5Do9u0GoN4gFn6Nk8NGDhh","331aH9HASX9R6xqRC3MJNH","0LyfQWJT6nXafLPZqxe9Of","4QMLZWebJZrhxGZsvctR4x","1uj8EOCKAXn4w2TR7CVnQb","6booSDXMipeW7NHm4ABRZr","6MK5Z7OjpkcN6OFe6nh8pi","5rxxIbW3FkBiFlKxCJbt6w","44DWomjW1oDuxIoBIRpmQ4","7c7Ffx5TX5jo4Avfo2YMch","5MmVJVhhYKQ86izuGHzJYA","4foFYflEloQE2Q9i1JPkNZ","0eDvMgVFoNV3TpwtrVCoTj","0LyfQWJT6nXafLPZqxe9Of","1uj8EOCKAXn4w2TR7CVnQb","4fIuC4t8qCtGEJFdkaru0S","3qUrABCNqnkb5gc2YmPVzP","7IVgVM49Z4ztdmOqOIxhvP","5yXENKinTRcO4i78rwHsBW","7BLGrzqCy8NElaGewQS6K5","0LjApYPFAPUvMYMb1gFJrc","3MJdWvzpiIvIjvZFwqpTR1","1zeIw5IiO7fsf5rWgvaFIB","4lSMHN0hTQWFJchmKwHE7Z","4QMLZWebJZrhxGZsvctR4x","1LcuxUEyzU0y52crxmATba","0LyfQWJT6nXafLPZqxe9Of","2SW8XasrJ7zfQwdzkx6q97","0LyfQWJT6nXafLPZqxe9Of","1XNKSJWrTew91OLYBR0Xg4","2GM4toz8PLIIzgPPSLN8gM","6apmlIDDsK3iSxCtZF6Sc9","526J8Yi6wnwWoOPuydTLaR","1G1Aqwpne900Zzhw3nxNol","0bxo4CrCrmhdgfAZQ2th36","3FGL9zcXC0ZcBFui2S9PxK",
        "3pcfIpTAeW7gE231DLRiiY","7hSks32NbjUq855ksjMlMg","6hcdM97tLhjVvZ8lmOwVFP","1xqlVMH5EAhhmHSRwhXJUy","1j27X4eKmVtnQ6TwbdXQb2","3pcfIpTAeW7gE231DLRiiY","1m7V9rstnZ264nGJe9MDUq","6x84IEh1pWMADJGEDJj7Zr","7iecnUUAJRZDCBNQR8Qmgk","5iDRheU42bDgBDRk87ospn","0LyfQWJT6nXafLPZqxe9Of","08yhhxlS2750gaCnRclDp9","3Lxq2snrWYiBj4SPZJm7oe","3pgCLfNbw5ozIfoNsvDU7i","0LyfQWJT6nXafLPZqxe9Of","1Emea6iLt1X27HTatnL7oV","0LyfQWJT6nXafLPZqxe9Of","1cf0sI5xmIozfrJXUWcRYo","0oxb3uhVq0HQLq3Oi7OIp7","0LyfQWJT6nXafLPZqxe9Of","5vpWEdK9C28uOX8jjfRi1v","3q45GtzDb65xPi6gFO3mMX","2u0gw0uCWBMiqV7h0N8kai","1G1Aqwpne900Zzhw3nxNol","4ZYjW9vY2BTk1er3xomkwI","5UQO8IQ2YE4eRUrGtHygB8","1VBflYyxBhnDc9uVib98rw","7F6474dJ7eusD2MkXm2Lwx","3ZHU5AKrUmIPnCFfr82QER","0dlDsD7y6ccmDm8tuWCU6F","05bZsDsrfQMnG83yks0Sg0","4ivfOZMa6lNjfcfpubOg6q","44CMqAkutKvmCaE2OxyCbd","1vVHevk2PD45epYnDi9CCc","4NhRml5ZOfNaYJAHUE0XwT","2SdcyCKXwjtQJymVLGyBlx","4STmXOXUF3UieHU46NWLVt","0eDvMgVFoNV3TpwtrVCoTj","0Zt1X6eSDuttQS3JHIyCvZ","2o5jDhtHVPhrJdv3cEQ99Z","4STmXOXUF3UieHU46NWLVt","5WqAC2eKe7UnQifadzN9r7","664Wsdghu6VKVDfJSmTEFT","6jkpUSaE5SFwUWWZyUe0dv","2utgbFODWxZ6ZPLVhRaToA","5mlbvTfWUOfDrUIK6dkNzv","0LyfQWJT6nXafLPZqxe9Of","1G1Aqwpne900Zzhw3nxNol","2x9SpqnPi8rlE9pjHBwmSC","4XikiVB4LdArUmsUFPg7kv","2SeRP5iAIhVec4azKHJzjX","0LyfQWJT6nXafLPZqxe9Of","7nV5hHONSsCDeqsOu1DLWr","5wTdspmxzb8V4ZjvDodpBo","5OdVywqKqyCWwfE2fZb7IX","1eUSEIGd3eCEUOeLFgJACg","2dvZ2hSWWctLAlk2nrHjJH","4EocOI6ihwLrX0mT95nBOT","75mafsNqNE1WSEVxIKuY5C","7aA592KWirLsnfb5ulGWvU"
      ];

      $id='';
      for ($i = 0; $i < 15; $i++) {
        $id = Arr::random($artistIds);
        if (!Artist::find($id)) {
          break;
        }
      }

      $data = ArtistSpotify::fromJson(\Spotify::artist($id)->get());

      return [
        'id' => $data->id ,
        'code' => $data->id,
        'name' => $data->name,
        'type' => $data->type,
        'popularity' => $data->popularity ?? 0,
        'imagedUrl' => $data->getImage(),
        'genre' => $data->getGenre(),
        'created_at' => Carbon::now(),
        'updated_at' => Carbon::now(),
      ];
    }
  }
