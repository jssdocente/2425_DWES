<x-layouts.app title="Artista">

  {{--  Diseña esta página--}}

</x-layouts.app>
