<nav class="flex items-center justify-between border-white/10 py-4">
  <div>
    <a href="/">
      <img class="h-16 w-16" src="{{ Vite::asset("resources/images/logo.webp") }}" alt="" />
    </a>
  </div>

  <div class="space-x-2 font-bold">
    {{--   Incluir los enlaces correspondientes--}}
  </div>

  <div>
    @auth
      <div class="flex items-center space-x-4">
        <x-dropdown class="relative ml-3">
          <x-slot name="trigger">
            <button
              class="flex rounded-full border-2 border-transparent text-sm transition duration-150 ease-in-out focus:border-gray-300 focus:outline-none"
              id="user-menu"
              aria-label="User menu"
              aria-haspopup="true"
            >
              <x-avatar search="driesvints" provider="github" class="h-8 w-8 rounded-full" />
            </button>
          </x-slot>

          <div class="absolute right-0 mt-2 w-48 origin-top-right rounded-md shadow-lg">
            <div class="shadow-xs rounded-md bg-white py-1">
              <a
                href="#"
                class="block px-4 py-2 text-sm leading-5 text-gray-700 transition duration-150 ease-in-out hover:bg-gray-100 focus:bg-gray-100 focus:outline-none"
              >
                {{ __("general.menu.Your Profile") }}
              </a>
              <a
                href="{{ route("user.settings") }}"
                class="block px-4 py-2 text-sm leading-5 text-gray-700 transition duration-150 ease-in-out hover:bg-gray-100 focus:bg-gray-100 focus:outline-none"
              >
                {{ __("general.menu.Settings") }}
              </a>
              <x-forms.button
                type="submit"
                form="logout-form"
                class="block w-full px-4 py-2 text-left text-sm leading-5 text-gray-700 transition duration-150 ease-in-out hover:bg-gray-100 focus:bg-gray-100 focus:outline-none"
              >
                {{ __("general.menu.Log-out") }}
              </x-forms.button>

              <x-forms.form id="logout-form" action="/logout" method="DELETE" />
            </div>
          </div>
        </x-dropdown>
        <p class="space-x-2">{{ Auth::user()->name }}</p>
      </div>
    @endauth

    @guest
      <div class="space-x-5 text-base font-bold">
        <a href="{{ route("register") }}" class="">Registrar</a>
        <a href="{{ route("login") }}" class="">Log-in</a>
      </div>
    @endguest
  </div>
</nav>
