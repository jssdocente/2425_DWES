<x-layouts.base :title="$title">
  <div class="px-10">
    <x-layouts.nav />

    <main class="mx-auto mt-10 max-w-[80rem]">
      <x-ui.flash-message/>
      {{ $slot }}
    </main>
  </div>
</x-layouts.base>
