<x-layouts.app title="Artista">
  <div class="mb-5">
    <h2 class="text-left text-2xl font-bold">Spotify > Album</h2>
    <section class="relative top-4 h-60 w-full pt-6 text-center">
      {{--      Crear un componente para la cabecera de los albúms/artistas a través del código siguiente--}}


      {{--      <img--}}
      {{--        class="h-full w-full rounded-t-lg object-cover opacity-30 blur-[2px]"--}}
      {{--        src="{{ $albumSpotify->getImage() }}"--}}
      {{--        alt=""--}}
      {{--      />--}}
      {{--      <div class="absolute bottom-10 left-8">--}}
      {{--        <h2 class="text-6xl font-bold">{{ $albumSpotify->name }}</h2>--}}
      {{--        <h2 class="top-14 pt-2 text-left text-2xl font-bold">Albúm</h2>--}}
      {{--      </div>--}}

    </section>

    <section class="my-12">
      <x-ui.section-heading>Canciones</x-ui.section-heading>
      {{--      Resto de la sección--}}
    </section>
  </div>
  <div class="h-12"></div>
</x-layouts.app>
