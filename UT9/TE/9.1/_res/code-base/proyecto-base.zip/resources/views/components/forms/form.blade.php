@php
  if ($attributes["method"] && $attributes->get("method") !== "GET") {
    switch ($attributes->get("method")) {
      case "PUT":
      case "PATCH":
        $attributes["_method"] = "PUT";
        break;
      case "DELETE":
        $attributes["_method"] = "DELETE";
        break;
    }
    $attributes["method"] = "POST";
  }
@endphp

<form {{ $attributes(["class" => "max-w-2xl mx-auto space-y-6", "method" => "GET"]) }}>
  @if ($attributes->get("method", "GET") !== "GET")
    @csrf
    @method($attributes->get("_method"))
  @endif

  {{ $slot }}
</form>
