<x-html
  :title="isset($title) ? $title . ' | ' . config('app.name') : ''"
  class="font-hanken-grotesk text-whitete h-dvh bg-slate-800 pb-20 leading-none text-white antialiased"
>
  <x-slot name="head">
    <x-social-meta title="{{ $component->title() }}" description="Tu catalogo de música con Laravel." />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />

    <link
      href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;500;600&display=swap"
      rel="stylesheet"
    />

    <link href="{{ asset('vendor/bladewind/css/animate.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('vendor/bladewind/css/bladewind-ui.min.css') }}" rel="stylesheet" />

    <script src="{{ asset('vendor/bladewind/js/helpers.js') }}"></script>
    <script src="//unpkg.com/alpinejs" defer></script>

    @vite(["resources/css/app.css", "resources/js/app.js"])
    @bukStyles
  </x-slot>

  {{ $slot }}

  @bukScripts
</x-html>
