<div>
    <div class="bg-white/10 my-10 h-px w-full"></div>
</div>
