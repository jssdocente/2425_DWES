<div class="relative min-w-32">
  <div class="absolute top-0 right-12">
    <div x-data="{show: true}" x-show="show" x-init="setTimeout(() => show=false, 6000)">
      @session('success')
      <x-ui.alerts.success :message="session('success')"/>
      @endsession

      @session('error')
      <x-ui.alerts.error :message="session('error')"/>
      @endsession

      @session('info')
      <x-ui.alerts.info :message="session('info')"/>
      @endsession

      @session('warning')
      <x-ui.alerts.warning :message="session('warning')"/>
      @endsession
    </div>
  </div>
</div>
