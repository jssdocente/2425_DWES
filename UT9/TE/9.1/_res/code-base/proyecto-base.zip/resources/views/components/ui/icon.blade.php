@props([
  "name",
  "size" => "xs",
])

@php
  switch ($size) {
    case "xl":
      $classes = "h-16 w-16";
      break;
    case "md":
      $classes = "h-12 w-12";
      break;
    case "xs":
      $classes = "h-6 w-6";
      break;
  }
@endphp

<div {{ $attributes->class($classes) }}>
  {{ svg($name) }}
</div>
