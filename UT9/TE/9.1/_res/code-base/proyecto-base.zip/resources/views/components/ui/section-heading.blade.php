<div {{ $attributes->class(["inline-flex items-center gap-x-2"]) }}>
  <span class="inline-block h-2 w-2 bg-white"></span>
  <h3 class="text-2xl font-bold">{{ $slot }}</h3>
</div>
