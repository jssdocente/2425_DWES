<button {{ $attributes->class(["class" => "rounded bg-blue-800 px-6 py-2 font-bold"]) }}>{{ $slot }}</button>
