@props([
  "title" => "",
  "size" => "base",
  "active" => "false",
])

@php
  $classes = "inline-flex items-center justify-center rounded-full px-4 py-1.5 text-lg font-medium";

  if ($size === "base") {
    $classes .= " px-4 py-1.5 text-lg";
  }

  if ($size === "small") {
    $classes .= " px-3 py-1 text-xs";
  }
@endphp

<div x-data="{ active: {{ $active }} }">
  <button
    {{ $attributes->class($classes) }}
    x-on:click="active=!active"
    x-bind:class="active ? 'bg-slate-900 text-white' : 'bg-gray-400 text-gray-600'"
  >
    {{ $slot }}
  </button>
</div>
