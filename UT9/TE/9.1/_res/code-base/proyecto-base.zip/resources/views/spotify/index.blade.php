<x-layouts.app title="Spotify">
  <section class="pt-6 text-center">
    <h1 class="text-4xl font-bold">Buscar música en Spotify</h1>
    {{--    Formulario de búsqueda--}}
  </section>
  @if ($query)
    <section class="pt-2 text-center">
      <div class="mt-6 flex flex-row flex-wrap justify-center gap-4">
        <x-ui.searchTag class="" active="true">Album</x-ui.searchTag>
        <x-ui.searchTag class="" active="true">Canciones</x-ui.searchTag>
        <x-ui.searchTag class="" active="true">Artista</x-ui.searchTag>
      </div>
    </section>

    <section class="pt-5">
      {{--      Section Featuring--}}
    </section>

    <section class="pt-5">
      {{--      Section Artist--}}
    </section>

    <section class="pt-5">
      {{--      Section Albums--}}
    </section>
  @else
    <section class="flex h-[32rem] flex-col items-center justify-center">
      <p class="text-2xl">Busca algo para animarnos...</p>
    </section>
  @endif
</x-layouts.app>
