<?php

namespace App\Http\Controllers;

use App\domain\spotify\{AlbumSpotify, ArtistSpotify, TrackSpotify};
use App\domain\MusicData;
use App\Models\Album;
use App\Models\Artist;
use App\Models\Track;
use Illuminate\Support\Arr;
use Spotify;
use Illuminate\Http\Request;

class SpotifyController extends Controller {


  public function search(Request $request) {

//    if (request('q') == '' ?? true) {
//      return view('spotify.index', [
//        'featuredAlbums' => [],
//        'albums' => [],
//        'artists' => [],
//        'query' => ''
//      ]);
//    }
//
//    $response = Spotify::searchItems(request('q'), 'album, artist')->get();
//
//    //Convertir a algo que podamos procesar
//    $albums = collect($response['albums']['items'])
//      ->map(fn($arr) => AlbumSpotify::fromJson($arr))
//      ->map(fn(AlbumSpotify $album) => $album->toInfo());
//
//    $featuredAlbums = collect($albums)
//      ->sortBy(fn(MusicData $data) => $data->popularity)
//      ->take(4);
//
//    $artist = collect($response['artists']['items'])
//      ->map(fn($arr) => ArtistSpotify::fromJson($arr))
//      ->map(fn(ArtistSpotify $artist) => $artist->toInfo());
//
//
//    return view('spotify.index', [
//      'featuredAlbums' => $featuredAlbums,
//      'albums' => $albums,
//      'artists' => $artist,
//      'query' => request('q')
//    ]);

//    return $albums;
  }

  public function showAlbum(Request $request, $id) {

//    $album = AlbumSpotify::fromJson(Spotify::album($id)->get());
//
//    $spotifyTracks = Spotify::albumTracks($id)->get();
//
//    $tracks = [];
//    foreach ($spotifyTracks['items'] as $track) {
//      $trackSpotify = TrackSpotify::fromJson($track);
//      $tracks[] = $trackSpotify;
//    }
//
//    return view('spotify.show-album', [
//      'albumSpotify' => $album,
//      'albumInBD' => Album::find($id),
//      'tracksSpotify' => $tracks
//    ]);

  }

  public function showArtist(Request $request, $id) {

//    $artist = ArtistSpotify::fromJson(Spotify::artist($id)->get());
//
//    $spotifyAlbums = Spotify::artistAlbums($id)->get();
//
//    $albums = [];
//    foreach ($spotifyAlbums['items'] as $item) {
//      $albums[] = AlbumSpotify::fromJson($item);
//    }
//
//    return view('spotify.show-artist', [
//      'artistSpotify' => $artist,
//      'artistBD' => Artist::find($id),
//      'albumsSpotify' => collect($albums)->map(fn($item)=>$item->toInfo())
//    ]);

  }


  public function create() {

    return view('spotify.index', [
      'featuredAlbums' => [],
      'albums' => [],
      'artists' => [],
      'query' => request('q')
    ]);

  }
}
