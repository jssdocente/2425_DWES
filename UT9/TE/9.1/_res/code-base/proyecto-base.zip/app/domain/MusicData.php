<?php

namespace App\domain;

readonly class MusicData {


   public string $id, $href, $name, $type, $imageUrl,$year,$genre,$artist;
   public int $followers,$popularity;

  /**
   * @param string $id
   * @param string $href
   * @param string $name
   * @param string $type
   * @param string $imageUrl
   * @param string $year
   * @param int $followers
   * @param string $genre
   * @param int $popularity
   */
  public function __construct(string $id, string $href, string $name, string $type, string $imageUrl, string $year, int $followers, string $genre, int $popularity=0, string $artist='') {
    $this->id = $id;
    $this->href = $href;
    $this->name = $name;
    $this->artist = $artist;
    $this->type = $type;
    $this->imageUrl = $imageUrl;
    $this->year = $year;
    $this->followers = $followers;
    $this->genre = $genre;
    $this->popularity = $popularity;
  }


}
