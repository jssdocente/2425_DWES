<?php

namespace App\domain\spotify;

use App\domain\MusicData;
use Illuminate\Support\Arr;

final readonly class ArtistSpotify extends MusicResourceBase
{
  public ExternalUrls $externalUrls;
  public Followers $followers;
  /** @var string[] */
  public array $genres;
  public string $href;
  public string $id;
  /** @var Images[] */
  public array $images;
  public string $name;
  public int $popularity;
  public string $type;
  public string $uri;

  /**
   * @param string[] $genres
   * @param Images[] $images
   */
  public function __construct(
    ExternalUrls $externalUrls,
    Followers $followers,
    array $genres,
    string $href,
    string $id,
    array $images,
    string $name,
    int $popularity,
    string $type,
    string $uri
  ) {
    $this->externalUrls = $externalUrls;
    $this->followers = $followers;
    $this->genres = $genres;
    $this->href = $href;
    $this->id = $id;
    $this->images = $images;
    $this->name = $name;
    $this->popularity = $popularity;
    $this->type = $type;
    $this->uri = $uri;
  }

  /**
   * Obtiene la imagen más pequeña
   * @return string
   */
  public function getImage(): string {
    return $this->images[0]->url ?? '';
  }

  /**
   * Obtiene la imagen más pequeña
   * @return string
   */
  public function getGenre(): string {
    return Arr::join($this->genres, ',','');
  }

  public static function fromJson(array $data): self
  {
    return new self(
      ExternalUrls::fromJson($data['external_urls'] ?? []),
      Followers::fromJson($data['followers'] ?? []),
      $data['genres'] ?? [],
      $data['href'],
      $data['id'],
      array_map(static function($data) {
        return Images::fromJson($data);
      }, $data['images'] ?? []),
      $data['name'],
      $data['popularity'] ?? 0,
      $data['type'],
      $data['uri']
    );
  }

  function toInfo(): MusicData {
    return new MusicData(
      id: $this->id,
      href: $this->href,
      name: $this->name,
      type: 'artist',
      imageUrl: $this->getImage(),
      year: '',
      followers: $this->followers?->total ?? 0,
      genre: implode(' ',$this->genres),
      popularity: 0
    );
  }
}
