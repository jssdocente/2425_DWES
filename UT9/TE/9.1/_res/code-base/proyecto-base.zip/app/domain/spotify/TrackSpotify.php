<?php

namespace App\domain\spotify;

use App\domain\MusicData;
use Illuminate\Support\Arr;


final readonly class TrackSpotify extends MusicResourceBase {
  public AlbumSpotify $album;
  /** @var ArtistSpotify[] */
  public array $artists;
  public int $discNumber;
  public int $durationMs;
  public int $duration;
  public bool $explicit;
  public ExternalUrls $externalUrls;
  public string $href;
  public string $id;
  public bool $isLocal;
  public bool $isPlayable;
  public string $name;
  public int $popularity;
  public null $previewUrl;
  public int $trackNumber;
  public string $type;
  public string $uri;

  /**
   * @param ArtistSpotify[] $artists
   */
  public function __construct(
    AlbumSpotify $album,
    array        $artists,
    int          $discNumber,
    int          $durationMs,
    bool         $explicit,
    ExternalUrls $externalUrls,
    string       $href,
    string       $id,
    bool         $isLocal,
    bool         $isPlayable,
    string       $name,
    int          $popularity,
    null         $previewUrl,
    int          $trackNumber,
    string       $type,
    string       $uri
  ) {
    $this->album = $album;
    $this->artists = $artists;
    $this->discNumber = $discNumber;
    $this->durationMs = $durationMs;
    $this->duration = $durationMs / 1000;
    $this->explicit = $explicit;
    $this->externalUrls = $externalUrls;
    $this->href = $href;
    $this->id = $id;
    $this->isLocal = $isLocal;
    $this->isPlayable = $isPlayable;
    $this->name = $name;
    $this->popularity = $popularity;
    $this->previewUrl = $previewUrl;
    $this->trackNumber = $trackNumber;
    $this->type = $type;
    $this->uri = $uri;
  }

  public static function fromJson(array $data): self {
    return new self(
      ($data['album'] ?? false)
        ? AlbumSpotify::fromJson($data['album'])
        : new AlbumSpotify()
      ,
      array_map(static function ($data) {
        return ArtistSpotify::fromJson($data);
      }, $data['artists']),
      $data['disc_number'],
      $data['duration_ms'],
      $data['explicit'],
      ExternalUrls::fromJson($data['external_urls'] ?? []),
      $data['href'],
      $data['id'],
      $data['is_local'],
      $data['is_playable'],
      $data['name'],
      $data['popularity'] ?? 0,
      $data['preview_url'] ?? null,
      $data['track_number'],
      $data['type'],
      $data['uri'] ?? ''
    );
  }

  function toInfo(): MusicData {
    return new MusicData(
      id: $this->id,
      href: $this->href,
      name: $this->name,
      type: 'track',
      imageUrl: $this->album->getImage(),
      year: $this->album->releaseDate,
      followers: 0,
      genre: Arr::join(Arr::map($this->artists, fn(ArtistSpotify $artist) => Arr::join($artist->genres,' ')), ' '),
      popularity: $this->popularity
    );
  }
}
