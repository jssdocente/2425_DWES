<?php

namespace App\domain\spotify;

use Illuminate\Support\Collection;
use function Sodium\add;

class SearchResponseSpotify {


  /**
   * @var Collection[Album]
   */
  private Collection $albums;

  private Collection $artist;

  public function __construct() {
    $this->albums = new Collection();
    $this->artist = new Collection();
  }

  public static function fromJson(array $data) {

    $instance = new self();

    if ($data['albums'] ?? false) {
      foreach ($data['albums']['items'] as $album) {
        $instance->albums->add(AlbumSpotify::fromJson($album));
      }
    }

    if ($data['artists'] ?? false) {
      foreach ($data['artists']['items'] as $artist) {
        $instance->artist->add(ArtistSpotify::fromJson($artist));
      }
    }

    return $instance;
  }

}
