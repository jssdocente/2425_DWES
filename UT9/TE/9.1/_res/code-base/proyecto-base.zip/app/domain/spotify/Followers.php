<?php

namespace App\domain\spotify;

final readonly class Followers
{
  public null $href;
  public int $total;

  public function __construct(null $href, int $total)
  {
    $this->href = $href;
    $this->total = $total;
  }

  public static function fromJson(array $data): self
  {
    return new self(
      $data['href'] ?? null,
      $data['total'] ?? 0
    );
  }
}
