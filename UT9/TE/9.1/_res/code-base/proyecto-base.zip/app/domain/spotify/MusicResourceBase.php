<?php

namespace App\domain\spotify;

use App\domain\MusicData;

abstract readonly class MusicResourceBase {

   abstract function toInfo(): MusicData ;

}
