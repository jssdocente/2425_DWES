<?php

namespace App\domain\spotify;

use App\domain\MusicData;
use Illuminate\Support\Arr;

final readonly class AlbumSpotify extends MusicResourceBase
{

  public string $albumType;
  public int $totalTracks;
  public bool $isPlayable;
  public ExternalUrls $externalUrls;
  public string $href;
  public string $id;
  /** @var Images[] */
  public array $images;
  public string $name;
  public string $releaseDate;
  public string $releaseDatePrecision;
  public string $type;
  public string $uri;
  /** @var ArtistSpotify[] */
  public array $artists;
  public array $genres;

  public static function fromJson(array $data): self
  {
    $instance = new self();
    $instance->albumType = $data['album_type'];
    $instance->totalTracks = $data['total_tracks'];
    $instance->isPlayable = $data['is_playable'] ?? true;
    $instance->externalUrls = ExternalUrls::fromJson($data['external_urls']);
    $instance->href = $data['href'];
    $instance->id = $data['id'];
    $instance->images = array_map(static function($data) {
      return Images::fromJson($data);
    }, $data['images']);
    $instance->name = $data['name'];
    $instance->releaseDate = $data['release_date'];
    $instance->releaseDatePrecision = $data['release_date_precision'];
    $instance->type = $data['type'];
    $instance->uri = $data['uri'];
    $instance->artists = array_map(static function($data) {
      return ArtistSpotify::fromJson($data);
    }, $data['artists']);
    $instance->genres = $data['genres'] ?? [];
    return $instance;
  }

  /**
   * Obtiene la imagen más pequeña
   * @return string
   */
  public function getImage(): string {
     return $this->images[0]->url ?? '';
  }

  /**
   * Obtiene la imagen más pequeña
   * @return string
   */
  public function getGenre(): string {
    return Arr::join($this->genres, ',','');
  }

  function toInfo(): MusicData {
    return new MusicData(
      id: $this->id,
      href: $this->href,
      name: $this->name,
      type: 'album',
      imageUrl: $this->getImage(),
      year: $this->releaseDate,
      followers: 0,
      genre: collect($this->artists)->map(fn(ArtistSpotify $artist)=>Arr::join($artist->genres, ' ')),
      artist: $this->artists[0]->name,
    );
  }
}
