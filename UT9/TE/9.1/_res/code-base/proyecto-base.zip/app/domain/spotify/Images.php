<?php

namespace App\domain\spotify;

final readonly class Images {
  public function __construct(
    public int    $height,
    public string $url,
    public int    $width
  ) {}

  public static function fromJson(array $data): self {
    return new self(
      $data['height'] ?? 0,
      $data['url'] ?? '',
      $data['width'] ?? 0
    );
  }
}
