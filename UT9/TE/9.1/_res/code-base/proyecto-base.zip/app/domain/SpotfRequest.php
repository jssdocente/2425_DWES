<?php

namespace App\domain;

use Aerni\Spotify\Clients\SpotifyClient;
use Aerni\Spotify\Exceptions\SpotifyApiException;
use Aerni\Spotify\Spotify;
use Aerni\Spotify\SpotifyAuth;
use Aerni\Spotify\SpotifyRequest;
use GuzzleHttp\Exception\RequestException;

class SpotfRequest extends SpotifyRequest {

    public function __construct() {
       $accessToken = resolve(SpotifyAuth::class)->getAccessToken();
       parent::__construct($accessToken);
    }

    public function getUrl(string $url) {
        try {

            $accessToken = resolve(SpotifyAuth::class)->getAccessToken();

            $response = (new SpotifyClient)->get($url, [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accepts' => 'application/json',
                    'Authorization' => 'Bearer '.$accessToken,
                ],
            ]);
        } catch (RequestException $e) {
            $errorResponse = $e->getResponse();
            $status = $errorResponse->getStatusCode();

            $message = $errorResponse->getReasonPhrase();

            throw new SpotifyApiException($message, $status, $errorResponse);
        }

        return json_decode((string) $response->getBody(), true);
    }
}
