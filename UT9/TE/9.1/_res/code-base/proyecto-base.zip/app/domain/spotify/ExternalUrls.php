<?php

namespace App\domain\spotify;

final readonly class ExternalUrls
{
  public function __construct(public string $spotify)
  {
  }

  public static function fromJson(array $data): self
  {
    return new self(
      $data['spotify'] ?? ''
    );
  }
}
