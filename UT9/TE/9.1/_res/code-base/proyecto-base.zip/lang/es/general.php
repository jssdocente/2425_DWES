<?php

return [

  "menu" => [
    "Login" => "Iniciar sesión",
    "Register" => "Registrar",
    "Log-out" => "Cerrar sesión",
    "Your Profile" => "Perfil",
    "Settings" => "Configuración",
  ]

];
