<?php

use App\Http\Controllers\{SpotifyController};
use Illuminate\Support\Facades\Route;

//Las rutas deben ser las que se indican, en la documentación del proyecto
