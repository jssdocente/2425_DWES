<?php
  if ($attributes["method"] && $attributes->get("method") !== "GET") {
    switch ($attributes->get("method")) {
      case "PUT":
      case "PATCH":
        $attributes["_method"] = "PUT";
        break;
      case "DELETE":
        $attributes["_method"] = "DELETE";
        break;
    }
    $attributes["method"] = "POST";
  }
?>

<form <?php echo e($attributes(["class" => "max-w-2xl mx-auto space-y-6", "method" => "GET"])); ?>>
  <?php if($attributes->get("method", "GET") !== "GET"): ?>
    <?php echo csrf_field(); ?>
    <?php echo method_field($attributes->get("_method")); ?>
  <?php endif; ?>

  <?php echo e($slot); ?>

</form>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\resources\views/components/forms/form.blade.php ENDPATH**/ ?>