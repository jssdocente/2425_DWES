<?php if (isset($component)) { $__componentOriginal24ce9465d95bb66368bee601d7e8c330 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal24ce9465d95bb66368bee601d7e8c330 = $attributes; } ?>
<?php $component = BladeUIKit\Components\Layouts\Html::resolve(['title' => isset($title) ? $title . ' | ' . config('app.name') : ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('html'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUIKit\Components\Layouts\Html::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-hanken-grotesk text-whitete h-dvh bg-slate-800 pb-20 leading-none text-white antialiased']); ?>
   <?php $__env->slot('head', null, []); ?> 
    <?php if (isset($component)) { $__componentOriginalafe6e9591150d8a3a8172da5102b9c5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalafe6e9591150d8a3a8172da5102b9c5a = $attributes; } ?>
<?php $component = BladeUIKit\Components\Layouts\SocialMeta::resolve(['title' => ''.e($component->title()).'','description' => 'Tu catalogo de música con Laravel.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('social-meta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUIKit\Components\Layouts\SocialMeta::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalafe6e9591150d8a3a8172da5102b9c5a)): ?>
<?php $attributes = $__attributesOriginalafe6e9591150d8a3a8172da5102b9c5a; ?>
<?php unset($__attributesOriginalafe6e9591150d8a3a8172da5102b9c5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalafe6e9591150d8a3a8172da5102b9c5a)): ?>
<?php $component = $__componentOriginalafe6e9591150d8a3a8172da5102b9c5a; ?>
<?php unset($__componentOriginalafe6e9591150d8a3a8172da5102b9c5a); ?>
<?php endif; ?>

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />

    <link
      href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;500;600&display=swap"
      rel="stylesheet"
    />

    <link href="<?php echo e(asset('vendor/bladewind/css/animate.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('vendor/bladewind/css/bladewind-ui.min.css')); ?>" rel="stylesheet" />

    <script src="<?php echo e(asset('vendor/bladewind/js/helpers.js')); ?>"></script>
    <script src="//unpkg.com/alpinejs" defer></script>

    <?php echo app('Illuminate\Foundation\Vite')(["resources/css/app.css", "resources/js/app.js"]); ?>
    <?php echo BladeUIKit\BladeUIKit::outputStyles(); ?>
   <?php $__env->endSlot(); ?>

  <?php echo e($slot); ?>


  <?php echo BladeUIKit\BladeUIKit::outputScripts(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal24ce9465d95bb66368bee601d7e8c330)): ?>
<?php $attributes = $__attributesOriginal24ce9465d95bb66368bee601d7e8c330; ?>
<?php unset($__attributesOriginal24ce9465d95bb66368bee601d7e8c330); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal24ce9465d95bb66368bee601d7e8c330)): ?>
<?php $component = $__componentOriginal24ce9465d95bb66368bee601d7e8c330; ?>
<?php unset($__componentOriginal24ce9465d95bb66368bee601d7e8c330); ?>
<?php endif; ?>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\resources\views/components/layouts/base.blade.php ENDPATH**/ ?>