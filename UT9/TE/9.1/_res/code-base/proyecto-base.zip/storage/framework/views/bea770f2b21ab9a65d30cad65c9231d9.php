<div>
    <div class="bg-white/10 my-10 h-px w-full"></div>
</div>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\resources\views/components/forms/divider.blade.php ENDPATH**/ ?>