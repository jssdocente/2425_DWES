<div x-data="{ open: false }" @click.outside="open = false" <?php echo e($attributes); ?>>
    <div @click="open = ! open">
        <?php echo e($trigger); ?>

    </div>

    <div x-show="open">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\vendor\blade-ui-kit\blade-ui-kit\src/../resources/views/components/navigation/dropdown.blade.php ENDPATH**/ ?>