<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  "data" => [],
  "size" => "xs",
  "height" => "300",
  "width" => "300",
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  "data" => [],
  "size" => "xs",
  "height" => "300",
  "width" => "300",
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
  switch ($size) {
    case "xl":
      $imgClasses = "h-64 w-64";
      break;
    case "md":
      $imgClasses = "h-48 w-48";
      break;
    case "xs":
      $imgClasses = "h-16 w-16";
      break;
  }

  switch ($data->type ?? "album") {
    case "artist":
      $imgClasses .= " rounded-full";
      break;
  }
?>

<div class="flex flex-col rounded-xl px-2 py-2 hover:bg-slate-900/30">
  <div class="header">
    <?php if($data->type === "album"): ?>
      <a href="<?php echo e(route("albums.show", ["id" => $data->id])); ?>">
        <img src="<?php echo e($data->imagedUrl); ?>" alt="" class="<?php echo e($imgClasses); ?> object-fit object-bottom" />
      </a>
    <?php elseif($data->type === "artist"): ?>
      <a href="<?php echo e(route("artists.show", ["id" => $data->id])); ?>">
        <img src="<?php echo e($data->imagedUrl); ?>" alt="" class="<?php echo e($imgClasses); ?> object-fit object-bottom" />
      </a>
    <?php endif; ?>
  </div>
  <div class="body mt-1 p-1">
    <p class="text-wrap text-lg font-medium leading-tight text-white"><?php echo e($data->name); ?></p>
    <?php if($data->type === "album"): ?>
      <div class="text-md mt-2 text-white/60">
        <time datetime="2005"><?php echo e($data->releaseDate); ?> •</time>
        <a draggable="false" dir="auto" href="/artists/<?php echo e($data->artist->id); ?>" aria-expanded="false">
          <?php echo e($data->artist->name); ?>

        </a>
        
        
        
      </div>
    <?php endif; ?>

    <?php if($data->type === "artist"): ?>
      <p class="mt-2 text-lg text-white/60">Artist</p>
    <?php endif; ?>
  </div>
</div>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\resources\views/components/music-card.blade.php ENDPATH**/ ?>