<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  /**@var\App\Models\Track*/"track",
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  /**@var\App\Models\Track*/"track",
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div <?php echo e($attributes->class(["flex flex-row"])); ?>>
  <div class="group relative" aria-roledescription="play button">
    <div class="h-30 flex w-20 flex-col items-center justify-center justify-items-center p-4 font-bold text-white/50">
      <img class="object-fill" src="<?php echo e($track->album->imagedUrl); ?>" alt="" />
    </div>
    
    <div
      class="absolute inset-4 flex flex-row items-center justify-center rounded-sm bg-black bg-opacity-80 py-2 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
      data-rule="user-actions"
    >
      <form id="form_add_album" method="POST" action="<?php echo e(route("tracks.play", ["id" => $track->id])); ?>">
        <button type="submit">
          <?php if (isset($component)) { $__componentOriginal56804098dcf376a0e2227cb77b6cd00a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56804098dcf376a0e2227cb77b6cd00a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.icon','data' => ['class' => 'p-1 text-white','name' => 'fluentui-play-24','size' => 'xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-1 text-white','name' => 'fluentui-play-24','size' => 'xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56804098dcf376a0e2227cb77b6cd00a)): ?>
<?php $attributes = $__attributesOriginal56804098dcf376a0e2227cb77b6cd00a; ?>
<?php unset($__attributesOriginal56804098dcf376a0e2227cb77b6cd00a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56804098dcf376a0e2227cb77b6cd00a)): ?>
<?php $component = $__componentOriginal56804098dcf376a0e2227cb77b6cd00a; ?>
<?php unset($__componentOriginal56804098dcf376a0e2227cb77b6cd00a); ?>
<?php endif; ?>
        </button>
        <?php echo csrf_field(); ?>
      </form>
    </div>
  </div>

  <div class="flex flex-1 flex-col justify-items-start py-1">
    <p class="text-xl font-bold"><?php echo e($track->name); ?></p>
    <a href="<?php echo e(route("albums.show", ["id" => $track->album->id])); ?>">
      <p class="text-sm underline"><?php echo e($track->album->name); ?></p>
    </a>
  </div>
  
  <p class="ml-2 flex h-12 w-12 items-center text-center font-semibold text-white/80">3:48</p>
  <p class="ml-2 flex h-12 w-12 items-center text-center font-semibold text-white/80"><?php echo e($track->playedTimes); ?></p>
</div>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\resources\views/components/track-card-image.blade.php ENDPATH**/ ?>