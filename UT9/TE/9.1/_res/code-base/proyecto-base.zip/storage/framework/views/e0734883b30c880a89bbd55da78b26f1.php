<div class="relative min-w-32">
  <div class="absolute top-0 right-12">
    <div x-data="{show: true}" x-show="show" x-init="setTimeout(() => show=false, 6000)">
      <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
      <?php if (isset($component)) { $__componentOriginalf6e429c98af5130d635e28f2a08b2e05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6e429c98af5130d635e28f2a08b2e05 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alerts.success','data' => ['message' => session('success')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alerts.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('success'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6e429c98af5130d635e28f2a08b2e05)): ?>
<?php $attributes = $__attributesOriginalf6e429c98af5130d635e28f2a08b2e05; ?>
<?php unset($__attributesOriginalf6e429c98af5130d635e28f2a08b2e05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6e429c98af5130d635e28f2a08b2e05)): ?>
<?php $component = $__componentOriginalf6e429c98af5130d635e28f2a08b2e05; ?>
<?php unset($__componentOriginalf6e429c98af5130d635e28f2a08b2e05); ?>
<?php endif; ?>
      <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

      <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
      <?php if (isset($component)) { $__componentOriginal3183e2507c2ac7e9f167dbf53d852945 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3183e2507c2ac7e9f167dbf53d852945 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alerts.error','data' => ['message' => session('error')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alerts.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('error'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3183e2507c2ac7e9f167dbf53d852945)): ?>
<?php $attributes = $__attributesOriginal3183e2507c2ac7e9f167dbf53d852945; ?>
<?php unset($__attributesOriginal3183e2507c2ac7e9f167dbf53d852945); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3183e2507c2ac7e9f167dbf53d852945)): ?>
<?php $component = $__componentOriginal3183e2507c2ac7e9f167dbf53d852945; ?>
<?php unset($__componentOriginal3183e2507c2ac7e9f167dbf53d852945); ?>
<?php endif; ?>
      <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

      <?php $__sessionArgs = ['info'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
      <?php if (isset($component)) { $__componentOriginal417e7e3bdd631a956648ac90862250da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal417e7e3bdd631a956648ac90862250da = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alerts.info','data' => ['message' => session('info')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alerts.info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('info'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal417e7e3bdd631a956648ac90862250da)): ?>
<?php $attributes = $__attributesOriginal417e7e3bdd631a956648ac90862250da; ?>
<?php unset($__attributesOriginal417e7e3bdd631a956648ac90862250da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal417e7e3bdd631a956648ac90862250da)): ?>
<?php $component = $__componentOriginal417e7e3bdd631a956648ac90862250da; ?>
<?php unset($__componentOriginal417e7e3bdd631a956648ac90862250da); ?>
<?php endif; ?>
      <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

      <?php $__sessionArgs = ['warning'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
      <?php if (isset($component)) { $__componentOriginal9f553fecde894750475eb1af74100dc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f553fecde894750475eb1af74100dc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alerts.warning','data' => ['message' => session('warning')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alerts.warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('warning'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f553fecde894750475eb1af74100dc3)): ?>
<?php $attributes = $__attributesOriginal9f553fecde894750475eb1af74100dc3; ?>
<?php unset($__attributesOriginal9f553fecde894750475eb1af74100dc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f553fecde894750475eb1af74100dc3)): ?>
<?php $component = $__componentOriginal9f553fecde894750475eb1af74100dc3; ?>
<?php unset($__componentOriginal9f553fecde894750475eb1af74100dc3); ?>
<?php endif; ?>
      <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
    </div>
  </div>
</div>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\resources\views/components/ui/flash-message.blade.php ENDPATH**/ ?>