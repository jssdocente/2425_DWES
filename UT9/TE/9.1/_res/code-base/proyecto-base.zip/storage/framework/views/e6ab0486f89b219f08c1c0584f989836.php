<div <?php echo e($attributes->class(["inline-flex items-center gap-x-2"])); ?>>
  <span class="inline-block h-2 w-2 bg-white"></span>
  <h3 class="text-2xl font-bold"><?php echo e($slot); ?></h3>
</div>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\resources\views/components/ui/section-heading.blade.php ENDPATH**/ ?>