<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  "title" => "",
  "size" => "base",
  "active" => "false",
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  "title" => "",
  "size" => "base",
  "active" => "false",
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
  $classes = "inline-flex items-center justify-center rounded-full px-4 py-1.5 text-lg font-medium";

  if ($size === "base") {
    $classes .= " px-4 py-1.5 text-lg";
  }

  if ($size === "small") {
    $classes .= " px-3 py-1 text-xs";
  }
?>

<div x-data="{ active: <?php echo e($active); ?> }">
  <button
    <?php echo e($attributes->class($classes)); ?>

    x-on:click="active=!active"
    x-bind:class="active ? 'bg-slate-900 text-white' : 'bg-gray-400 text-gray-600'"
  >
    <?php echo e($slot); ?>

  </button>
</div>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\resources\views/components/ui/searchTag.blade.php ENDPATH**/ ?>