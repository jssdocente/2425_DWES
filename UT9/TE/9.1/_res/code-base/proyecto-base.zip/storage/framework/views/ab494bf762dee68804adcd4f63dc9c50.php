<form method="POST" action="<?php echo e($action); ?>">
    <?php echo csrf_field(); ?>

    <button type="submit" <?php echo e($attributes); ?>>
        <?php echo e($slot->isEmpty() ? __('Log out') : $slot); ?>

    </button>
</form>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\vendor\blade-ui-kit\blade-ui-kit\src/../resources/views/components/buttons/logout.blade.php ENDPATH**/ ?>