<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  "data" => [],
  "size" => "xs",
  "height" => "300",
  "width" => "300",
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  "data" => [],
  "size" => "xs",
  "height" => "300",
  "width" => "300",
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
  switch ($size) {
    case "xl":
      $imgClasses = "h-64 w-64";
      break;
    case "md":
      $imgClasses = "h-48 w-48";
      break;
    case "xs":
      $imgClasses = "h-16 w-16";
      break;
  }

  switch ($data->type ?? "album") {
    case "artist":
      $imgClasses .= " rounded-full";
      break;
  }
?>

<div class="flex flex-col rounded-xl px-2 py-2 hover:bg-slate-900/30">
  <div class="header group relative">
    <img src="<?php echo e($data->imageUrl); ?>" alt="" class="<?php echo e($imgClasses); ?> object-fit object-bottom" />
    
    <div
      class="absolute inset-0 flex flex-row items-center justify-center bg-black bg-opacity-50 py-2 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
      data-rule="user-actions"
    >
      <a
        href="<?php echo e($data->type === "album" ? route("spotify.show-album", ["id" => $data->id]) : route("spotify.show-artist", ["id" => $data->id])); ?>"
      >
        <?php if (isset($component)) { $__componentOriginal56804098dcf376a0e2227cb77b6cd00a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56804098dcf376a0e2227cb77b6cd00a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.icon','data' => ['class' => 'rounded-full p-1 text-white','name' => 'fluentui-info-28','size' => 'xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'rounded-full p-1 text-white','name' => 'fluentui-info-28','size' => 'xl']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56804098dcf376a0e2227cb77b6cd00a)): ?>
<?php $attributes = $__attributesOriginal56804098dcf376a0e2227cb77b6cd00a; ?>
<?php unset($__attributesOriginal56804098dcf376a0e2227cb77b6cd00a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56804098dcf376a0e2227cb77b6cd00a)): ?>
<?php $component = $__componentOriginal56804098dcf376a0e2227cb77b6cd00a; ?>
<?php unset($__componentOriginal56804098dcf376a0e2227cb77b6cd00a); ?>
<?php endif; ?>
      </a>
    </div>
  </div>
  <div class="body mt-1 p-1">
    <?php if($data->type === "album"): ?>
      <a class="" href="/spotify/album/<?php echo e($data->id); ?>">
        <p class="text-wrap text-lg font-medium leading-tight text-white"><?php echo e($data->name); ?></p>
      </a>
      <div class="text-md mt-2 text-white/60">
        <time datetime="2005"><?php echo e($data->year); ?> •</time>
        <a draggable="false" dir="auto" href="/artist/0fM3rWsshliRFUmJlBP6QZ" aria-expanded="false">
          <?php echo e($data->artist); ?>

        </a>
        
        
        
      </div>
    <?php endif; ?>

    <?php if($data->type === "artist"): ?>
      <div>
        <a class="">
          <p class="text-wrap text-lg font-medium leading-tight text-white"><?php echo e($data->name); ?></p>
        </a>
        <p class="mt-2 text-lg text-white/60">Artist</p>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php /**PATH F:\docente\2425\DWES\_repos\profesor\dwes_laravel_proyecto_final-9.1\resources\views/components/music-card-spotify.blade.php ENDPATH**/ ?>