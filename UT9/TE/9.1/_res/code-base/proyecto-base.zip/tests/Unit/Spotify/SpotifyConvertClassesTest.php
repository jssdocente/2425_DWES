<?php

//namespace Tests\Unit\Spotify;

use App\domain\{SpotfRequest,
  spotify\AlbumSpotify,
  spotify\ArtistSpotify,
  spotify\ExternalUrls,
  spotify\Followers,
  spotify\Images,
  spotify\SearchResponseSpotify,
  spotify\TrackSpotify};

it('can convert spotify-album-object to album class', function () {

  $jsonPath = __DIR__ . '/../../_data/spotify/album.json';
  $jsonAlbum = file_get_contents($jsonPath);

  //Act
  $album = AlbumSpotify::fromJson(json_decode($jsonAlbum, true));

  //Assert
  expect($album)->toBeInstanceOf(AlbumSpotify::class)
    ->and($album->albumType)->toBe('album')
    ->and($album->totalTracks)->toBe(15)
    ->and($album->isPlayable)->toBeTrue()
    ->and($album->externalUrls)->toBeInstanceOf(ExternalUrls::class)
    ->and($album->href)->toBe('https://api.spotify.com/v1/albums/2udnM4E7aLSfcpSlPEUOUm')
    ->and($album->id)->toBe('2udnM4E7aLSfcpSlPEUOUm')
    ->and($album->name)->toBe('Barrio Sésamo')
    ->and($album->releaseDate)->toBe('1985')
    ->and($album->releaseDatePrecision)->toBe('year')
    ->and($album->type)->toBe('album')
    ->and($album->artists)->toBeArray()
    ->and($album->artists[0])->toBeInstanceOf(ArtistSpotify::class)
    ->and($album->images)->toBeArray()
    ->and($album->images[0])->toBeInstanceOf(Images::class);
});

it('can convert spotify-artis-object to artis class', function () {

  $jsonPath = __DIR__ . '/../../_data/spotify/artist.json';
  $jsonContent = file_get_contents($jsonPath);

  //Act
  $artist = ArtistSpotify::fromJson(json_decode($jsonContent, true));

  //Assert
  expect($artist)->toBeInstanceOf(ArtistSpotify::class)
    ->and($artist->name)->toBe('El Barrio')
    ->and($artist->id)->toBe('0fM3rWsshliRFUmJlBP6QZ')
    ->and($artist->popularity)->toBe(60)
    ->and($artist->type)->toBe('artist')
    ->and($artist->genres)->toBeArray()->toContain('flamenco', 'flamenco pop')
    ->and($artist->externalUrls)->toBeInstanceOf(ExternalUrls::class)
    ->and($artist->followers)->toBeInstanceOf(Followers::class)
    ->and($artist->followers->total)->toBe(1291982)
    ->and($artist->images)->toBeArray()
    ->and($artist->images[0])->toBeInstanceOf(Images::class);
});

it('can convert spotify-track-album-object to track class', function () {

  $jsonPath = __DIR__ . '/../../_data/spotify/track.json';
  $jsonContent = file_get_contents($jsonPath);

  //Act
  $track = TrackSpotify::fromJson(json_decode($jsonContent, true));

  //Assert
  expect($track)->toBeInstanceOf(TrackSpotify::class)
    ->and($track->name)->toBe('Barrio')
    ->and($track->id)->toBe('5FCOXn36ls2qu1E4VmvAiL')
    ->and($track->type)->toBe('track')
    ->and($track->artists[0]->name)->toBe('Ashafar')
    ->and($track->album->name)->toBe('Barrio')
    ->and($track->trackNumber)->toBe(1)
    ->and($track->duration)->toBe(156)
    ->and($track->isPlayable)->toBeTrue()
    ->and($track->discNumber)->toBe(1);
});
