<?php

use App\domain\spotify\AlbumSpotify;
use App\Models\Artist;
use Tests\TestCase;
use App\Models\Album;

it('can create album from spotify-id', function () {

  $data = [
    'albumid' => '6dODtvKEopRhK5dKC7OZD6',
    'artist' => [
      'id' => '6hcdM97tLhjVvZ8lmOwVFP',
      'image' => 'https://i.scdn.co/image/ab67616d0000b2731fc17d2e68228aaf17c12a0f'
      ]
  ];

  $id = '2udnM4E7aLSfcpSlPEUOUm';

  //Actuar
  $albumDb =Album::createFromSpotify($data['albumid']);

  //Validar un album
  $this->assertDatabaseHas('artists', ['id'=> $data['artist']['id'], 'code' => $data['artist']['id']]);
  $this->assertDatabaseHas('albums', ['id'=> $data['albumid'], 'code' => $data['albumid']]);

  expect($albumDb->artist->imagedUrl)->toBe($data['artist']['image']);

});


