<?php

namespace Tests\Unit\Spotify;

use App\domain\SpotfRequest;
use App\domain\spotify\SearchResponseSpotify;

class SpotifyRequestTest extends \Tests\TestCase {

    public function test_can_get_url(): void
    {
        $rq = new SpotfRequest();
        $response = $rq->getUrl("https://api.spotify.com/v1/search?offset=10&limit=10&query=Barrio&type=album&market=ES");


        SearchResponseSpotify::fromJson($response);

        $this->assertEquals(200, $response->getStatusCode());
    }

}
