<?php

use App\Models\Album;

test('', function () {
  expect(true)->toBeTrue();
});


it('can create album from spotify-id', function() {

  $data = [
    'id' => '2udnM4E7aLSfcpSlPEUOUm',
    'artist_id' => '7Gr8DVj6UF1YDiwefvMSnA',
    'artist_name' => 'Espinete y Sus Amigos'
  ];

  //Actuar
  $response = $this->post(route('albums.store'), $data);

  //Validar
  $this->assertDatabaseHas('albums',['id'=> $data['id'], 'code'=> $data['id']]);
  $this->assertDatabaseHas('artists',['id'=> $data['artist_id'], 'code'=> $data['artist_id']]);

  $album = Album::find($data['id']);
  expect($album->artist->name)->toBe($data['artist_name']);

});

