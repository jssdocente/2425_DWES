<?php

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;

uses(RefreshDatabase::class);

test('deberia crear cuenta usuario e iniciar-sesión', function () {

  $userData = [
    'name' => 'John Doe',
    'email' => 'john@example.com',
    'password' => 'password123',
    'password_confirmation' => 'password123',
  ];

  // Hacer la petición POST a la ruta de registro
  $response = $this->post(route('register'), $userData);

  // Verificar que el usuario fue creado
  $this->assertDatabaseHas('users', [
    'name' => 'John Doe',
    'email' => 'john@example.com'
  ]);

  //Verificar que el usuario está autenticado
  $this->assertAuthenticated();

  //Verificar que se redirige a la página principal
  $response->assertRedirect('/');

});
