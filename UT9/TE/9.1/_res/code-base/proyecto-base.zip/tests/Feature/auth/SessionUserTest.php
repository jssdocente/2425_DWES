<?php

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;

uses(RefreshDatabase::class);

test('permite a un usuario iniciar-sesión', function () {

  //Crear un usuario en la BD
  $user = User::factory()->create([
    'password' => bcrypt('password123')
  ]);

  //Intentar iniciar-sesión
  $response = $this->post(route('login'), [
    'email' => $user->email,
    'password' => 'password123'
  ]);

  //Verificar que el usuario está autenticado
  $this->assertAuthenticated();

  //Verificar que se redirige a la página principal
  $response->assertRedirect(route('dashboard.index'));

});

test('permite a un usuario cerrar sesión', function () {

    //Crear un usuario en la BD
    $user = User::factory()->create();

    //Iniciar-sesión
    $this->actingAs($user);

    //Cerrar sesión
    $response = $this->delete(route('logout'));

    //Verificar que el usuario no está autenticado
    $this->assertGuest();

    //Verificar que se redirige a la página de inicio de sesión
    $response->assertRedirect(route('dashboard.index'));
});
